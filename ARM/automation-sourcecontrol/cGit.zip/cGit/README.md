﻿# cGit
A DSC module for managing Git repositories
