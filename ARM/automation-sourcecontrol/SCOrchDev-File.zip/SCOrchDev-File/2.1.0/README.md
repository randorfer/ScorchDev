﻿# SCOrchDev-File
PowerShell module for dealing with files
