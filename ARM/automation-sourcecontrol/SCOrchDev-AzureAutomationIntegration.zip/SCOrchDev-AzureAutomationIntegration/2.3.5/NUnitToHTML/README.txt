NUnit2Report Console is a tool to transform the NUnit xml results file to an Html user-friendly report using XSL files, the tool was originally designed to be integrated with NAnt as a NAnt task and it was created by Gilles Bayon. This version converts the original NUnittoReportTask to a console version to be able to use it freely without the use of NAnt.

This tool is avalaible as a Nuget package: "NUnit2Report.Console.Runner"
You can find more information about this tool in:
https://github.com/jupaol/NUnit2Report.Console

This is a translation from NUnit2ReportTask.cs

The purpose is to create a Console version from: "NUnit2ReportTask"

NUnit2ReportTask Information:

http://nunit2report.sourceforge.net/
http://sourceforge.net/projects/nunit2report
http://weblogs.asp.net/thangchung/archive/2010/12/17/generating-report-for-nunit.aspx

People can contact Gilles Bayon via the mail address gilles.bayon@laposte.net or website  http://nunit2report.sourceforge.net